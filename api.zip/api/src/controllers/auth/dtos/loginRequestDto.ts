interface loginRequestDto {
  email: string;
  password: string;
}

export default loginRequestDto;

interface currentUserResponseDto {
  id: string;
  username: string;
  email: string;
}

export default currentUserResponseDto;

import { Request, Response } from "express";
import { DI } from "../../app";
import { Game } from "../../entities";
import uuid4 from "uuid4";

export class GameController {
  static getAllGames = async (req: Request, res: Response) => {
    const currentUser = req.user;

    const allGames = await DI.gameRepository.findAll({
      owner: currentUser,
    });

    return res.json({ allGames });
  };

  static createGame = async (req: Request, res: Response) => {
    const currentUser = req.user;

    const newGame = DI.em.create(Game, {
      type: "bataille-simple",
      code: uuid4(),
      owner: currentUser,
    });

    await DI.em.persistAndFlush(newGame);

    return res.json({ newGame });
  };
}

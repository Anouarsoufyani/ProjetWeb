import {
  Entity,
  // Collection,
  OneToMany,
  PrimaryKey,
  Property,
  Unique,
} from "@mikro-orm/core";
import { ObjectId } from "@mikro-orm/mongodb";
import { Game } from "./Game";

@Entity()
@Unique({ properties: ["username", "email"] })
export class User {
  @PrimaryKey()
  _id: ObjectId | undefined;

  @Property({ type: "date" })
  createdAt = new Date();

  @Property({ type: "date", onUpdate: () => new Date() })
  updatedAt = new Date();

  @Property()
  username!: string;

  @Property()
  email!: string;

  @Property()
  password!: string;

  @OneToMany(() => Game, (game) => game.owner)
  games: Game[] | undefined;
}
